<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Full Slider - Start Bootstrap Template</title>

        <!-- Bootstrap core CSS -->
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="css/full-slider.css" rel="stylesheet">

        <link href="css/heroic-features.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style type="text/css">
            .sidenav {
                height: 100%;
                width: 0;
                position: fixed;
                z-index: 99;
                top: 0;
                right: 0;
                background-color: white;
                overflow-x: hidden;
                transition: 0.5s;
                padding-top: 60px;


            }
            .sidenav ul{
                list-style: none;
                margin: 0px;
                padding: 0px;
            }

            .sidenav ul li{
                width: 100%;
                height: 70px;

                border-bottom: 1px solid gray;
            }

            .sidenav a {
                padding: 8px 8px 8px 8px;
                text-decoration: none;
                font-size: 25px;
                color: #818181;
                display: block;
                transition: 0.3s;

            }


            .sidenav .closebtn {

                margin-top: 10px;
                text-align: left;
                font-size: 18px;
                color:red;

            }
            .floatview{
                float: left;
                margin-left: 10px;

            }
            .name{
                width: 160px;

            }
        </style>


    </head>

    <body>
        <div id="mySidenav" class="sidenav">
            <div>
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-close"></i> Close</a>
            </div>
            <ul>
                <li style="height:30px; background:black; color:white;"><div class="floatview name">Item</div><div class="floatview count">qty</div>&nbsp;&nbsp;&nbsp;<div class="floatview count">Total</div></li>

            </ul>
            <ul id="show-cart">

            </ul>
            <h3 style="text-align:right;"><span>Subtotal:&nbsp;</span>Tk.&nbsp;<span id="total-cart"></span><span>/-</span>&nbsp;&nbsp;</h3>

        </div>
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shopping_cart.php">Shopping Cart</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="accounting.php">Basic Accounting</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link lg" href="#" onclick="openNav()">
                                Cart <i class="fa fa-shopping-cart"></i><sup><span id="count-cart" style="background:white; border-radius:50px; color:black; font-size:16px;">0</span></sup>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <header>
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>

        </header>

        <!-- Page Content -->
        <section class="py-5">
            <div class="container">

                <h1>Shopping Cart</h1>

                <br/>
                <!-- Page Features -->
                <div class="row text-center">

                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card">
                            <img class="card-img-top" src="images/orange.jpg" width="500px" height="200px" alt="">
                            <div class="card-body">
                                <h4 class="card-title">Cart title</h4>
                                <h5 class="card-title">Price : 150</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
                            </div>
                            <div class="card-footer">
                                <a href="#" class="btn btn-primary add-to-cart" href="#" data-name="Orange 1kg / 150 tk" data-price="150">Add to Cart</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card">
                            <img class="card-img-top" src="images/apple.jpg" width="500px" height="200px" alt="">
                            <div class="card-body">
                                <h4 class="card-title">Cart title</h4>
                                <h5 class="card-title">Price : 220</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo magni sapiente, tempore debitis beatae culpa natus architecto.</p>
                            </div>
                            <div class="card-footer">
                                <a href="#" class="btn btn-primary add-to-cart" href="#" data-name="Apple 1kg / 220 tk" data-price="220">Add to Cart</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card">
                            <img class="card-img-top" src="images/banana.jpg" width="500px" height="200px" alt="">
                            <div class="card-body">
                                <h4 class="card-title">Cart title</h4>
                                <h5 class="card-title">Price : 100</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
                            </div>
                            <div class="card-footer">
                                <a href="#" class="btn btn-primary add-to-cart" href="#" data-name="Banana 12 Pcs / 100 tk" data-price="100">Add to Cart</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card">
                            <img class="card-img-top" src="images/guava.jpg" width="500px" height="200px" alt="">
                            <div class="card-body">
                                <h4 class="card-title">Cart title</h4>
                                <h5 class="card-title">Price : 60</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo magni sapiente, tempore debitis beatae culpa natus architecto.</p>
                            </div>
                            <div class="card-footer">
                                <a href="#" class="btn btn-primary add-to-cart" href="#" data-name="Guava 1kg / 60 tk" data-price="60">Add to Cart</a>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.row -->

            </div>
            <!-- /.container -->
        </section>

        <!-- Footer -->
        <footer class="py-0 bg-dark">

            <!-- /.container -->
        </footer>

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    </body>

</html>
<script src="js/shoppingCart.js"></script>

<script>
                                function openNav() {
                                    document.getElementById("mySidenav").style.width = "360px";
                                }

                                function closeNav() {
                                    document.getElementById("mySidenav").style.width = "0";
                                }
</script>
<script>

    $(".add-to-cart").click(function (event) {
        event.preventDefault();
        var name = $(this).attr("data-name");
        var price = Number($(this).attr("data-price"));

        shoppingCart.addItemToCart(name, price, 1);
        displayCart();
    });

    $("#clear-cart").click(function (event) {
        shoppingCart.clearCart();
        displayCart();
    });

    function displayCart() {
        var cartArray = shoppingCart.listCart();
        console.log(cartArray);
        var output = "";

        for (var i in cartArray) {
            output += "<li>" + "<div class='floatview name'><p>" + cartArray[i].name + "<br>" + " <button class='delete-item' data-name='"
                    + cartArray[i].name + "' style='background:red; font-size:12px;'>remove</button>" + "</p></div><div class='floatview count'><p>" + cartArray[i].count + "&nbsp;&nbsp;&nbsp;" + cartArray[i].total + "&nbsp;&nbsp;&nbsp;" + "<button class='plus-item' data-name='"
                    + cartArray[i].name + "'>+</button>" + " <button class='subtract-item' data-name='"
                    + cartArray[i].name + "'>-</button>" + "</p></div></li>";
        }

        $("#show-cart").html(output);
        $("#count-cart").html(shoppingCart.countCart());
        $("#total-cart").html(shoppingCart.totalCart());
    }

    $("#show-cart").on("click", ".delete-item", function (event) {
        var name = $(this).attr("data-name");
        shoppingCart.removeItemFromCartAll(name);
        displayCart();
    });

    $("#show-cart").on("click", ".subtract-item", function (event) {
        var name = $(this).attr("data-name");
        shoppingCart.removeItemFromCart(name);
        displayCart();
    });

    $("#show-cart").on("click", ".plus-item", function (event) {
        var name = $(this).attr("data-name");
        shoppingCart.addItemToCart(name, 0, 1);
        displayCart();
    });

    $("#show-cart").on("change", ".item-count", function (event) {
        var name = $(this).attr("data-name");
        var count = Number($(this).val());
        shoppingCart.setCountForItem(name, count);
        displayCart();
    });


    displayCart();

</script>
