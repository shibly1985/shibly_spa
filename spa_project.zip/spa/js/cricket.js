$(document).ready(function () {
    var val = 1;
    $('#run1').click(function () {
        $('#total_run').html(function (i, val) {
            return val * 1 + 1;
        });
    });

    $('#run2').click(function () {
        $('#total_run').html(function (i, val) {
            return val * 1 + 2;
        });
    });

    $('#run3').click(function () {
        $('#total_run').html(function (i, val) {
            return val * 1 + 3;
        });
    });

    $('#run4').click(function () {
        $('#total_run').html(function (i, val) {
            return val * 1 + 4;
        });
    });

    $('#run5').click(function () {
        $('#total_run').html(function (i, val) {
            return val * 1 + 5;
        });
    });

    $('#run6').click(function () {
        $('#total_run').html(function (i, val) {
            return val * 1 + 6;
        });
    });



    var over = 1;
    $('.p1').click(function () {
        $('#total_over').html(function (i, over) {
            var ball = over * 1 + 1;
            var balls;
            /*
             * calculate ball to over
             if (ball < 6) {
             balls = ball;
             } else {
             var over, rest_ball;
             over = parseInt(ball / 6);
             rest_ball = parseInt(ball % 6);
             //balls = "" + over + b;
             balls = a;
             //balls =over +"."+ b;
             }
             */
            return ball;

        });
    });

    //////////////////////////////////////////////////
    //var p2_val = 1;
    $('#p2_run1').click(function () {
        $('#p2_total_run').html(function (p2_i, p2_val) {
            return p2_val * 1 + 1;
        });
    });

    $('#p2_run2').click(function () {
        $('#p2_total_run').html(function (p2_i, p2_val) {
            return p2_val * 1 + 2;
        });
    });

    $('#p2_run3').click(function () {
        $('#p2_total_run').html(function (p2_i, p2_val) {
            return p2_val * 1 + 3;
        });
    });

    $('#p2_run4').click(function () {
        $('#p2_total_run').html(function (p2_i, p2_val) {
            return p2_val * 1 + 4;
        });
    });

    $('#p2_run5').click(function () {
        $('#p2_total_run').html(function (p2_i, p2_val) {
            return p2_val * 1 + 5;
        });
    });

    $('#p2_run6').click(function () {
        $('#p2_total_run').html(function (p2_i, p2_val) {
            return p2_val * 1 + 6;
        });
    });



    var p2_over = 1;
    $('.p2').click(function () {
        $('#p2_total_over').html(function (p2_i, p2_over) {
            var p2_ball = p2_over * 1 + 1;
            return p2_ball;

        });
    });

});